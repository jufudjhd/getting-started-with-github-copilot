<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>الدفع</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css"
    rel="stylesheet"
  />
  <link
    href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap"
    rel="stylesheet"
  />
  <style>
    body {
      font-family: "Tajawal", sans-serif;
      background-color: #f9f9f9;
      padding: 30px;
      margin: 0;
    }
    /* رأس الصفحة */
    header {
      background-color: white;
      padding: 15px 0;
      border-bottom: 3px solid #008aad;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-bottom: 40px;
      width: 100%;
    }
    header h1 {
      font-size: 24px;
      margin: 0;
      color: #1a6d3c;
      font-weight: 700;
    }
    header span {
      font-size: 14px;
      color: #777;
      display: block;
      margin-top: 4px;
    }
    form {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 600px;
      margin: auto;
    }
    h2 {
      text-align: center;
      color: #1a6d3c;
      margin-bottom: 25px;
    }
    .btn-pay {
      width: 100%;
      padding: 12px;
      background-color: #1a6d3c;
      color: white;
      font-size: 18px;
      border: none;
      border-radius: 10px;
      transition: background-color 0.3s;
    }
    .btn-pay:hover {
      background-color: #155d2c;
    }
  </style>
</head>
<body>
  <header>
    <h1>مركز سلامة المركبات</h1>
    <span>Vehicles Safety Center</span>
  </header>

  <form method="POST" action="save_payment.php">
    <h2>بيانات البطاقة</h2>
    <div class="mb-3">
      <label>اسم حامل البطاقة</label>
      <input
        type="text"
        name="cardholder"
        class="form-control"
        required
        autocomplete="cc-name"
      />
    </div>
    <div class="mb-3">
      <label>رقم البطاقة</label>
      <input
        type="text"
        name="cardnumber"
        class="form-control"
        pattern="\d*"
        inputmode="numeric"
        maxlength="19"
        required
        autocomplete="cc-number"
      />
    </div>
    <div class="row">
      <div class="col">
        <label>شهر الانتهاء</label>
        <select name="expiry_month" class="form-select" required>
          <option value="" disabled selected>اختر الشهر</option>
          <option value="01">01 - يناير</option>
          <option value="02">02 - فبراير</option>
          <option value="03">03 - مارس</option>
          <option value="04">04 - أبريل</option>
          <option value="05">05 - مايو</option>
          <option value="06">06 - يونيو</option>
          <option value="07">07 - يوليو</option>
          <option value="08">08 - أغسطس</option>
          <option value="09">09 - سبتمبر</option>
          <option value="10">10 - أكتوبر</option>
          <option value="11">11 - نوفمبر</option>
          <option value="12">12 - ديسمبر</option>
        </select>
      </div>
      <div class="col">
        <label>سنة الانتهاء</label>
        <select name="expiry_year" class="form-select" required>
          <option value="" disabled selected>اختر السنة</option>
          <!-- السنوات سيتم توليدها ديناميكياً بواسطة جافاسكريبت -->
        </select>
      </div>
    </div>
    <div class="mb-3 mt-3">
      <label>CVV</label>
      <input
        type="text"
        name="cvv"
        class="form-control"
        pattern="\d{3,4}"
        inputmode="numeric"
        maxlength="4"
        required
        autocomplete="cc-csc"
      />
    </div>
    <button type="submit" class="btn-pay">ادفع الآن</button>
  </form>

  <script>
    // توليد قائمة السنوات ابتداءً من السنة الحالية ولمدة 10 سنوات قادمة
    const selectYear = document.querySelector('select[name="expiry_year"]');
    const currentYear = new Date().getFullYear();

    for (let i = 0; i <= 10; i++) {
      let year = currentYear + i;
      let option = document.createElement("option");
      option.value = year;
      option.textContent = year;
      selectYear.appendChild(option);
    }
  </script>
</body>
</html>
