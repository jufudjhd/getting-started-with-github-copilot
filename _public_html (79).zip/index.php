<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>موقع الدفع الإلكتروني</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background-color: #eef1f4;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: white;
      padding: 15px;
      text-align: center;
      border-bottom: 3px solid #008aad;
    }
    header img.logo {
      height: 60px;
      margin-bottom: 5px;
    }
    .main-content {
      max-width: 500px;
      margin: 30px auto;
      text-align: center;
    }
    .title {
      font-size: 24px;
      font-weight: bold;
      color: #333;
      margin-bottom: 15px;
    }
    .subtitle {
      font-size: 16px;
      color: #444;
      margin-bottom: 30px;
    }
    .btn-salama {
      border-radius: 50px;
      font-size: 18px;
      padding: 10px;
      width: 100%;
    }
    .btn-hijz {
      background-color: #1a6d3c;
      color: white;
      border: none;
    }
    .btn-ta3deel {
      border: 2px solid #000;
      color: #000;
      background-color: white;
    }
    .btn-ighaa {
      border: 2px solid #dc3545;
      color: #dc3545;
      background-color: white;
    }
    .app-section {
      background-color: #0099b3;
      color: white;
      padding: 40px 20px;
      text-align: center;
    }
    .app-section h2 {
      font-size: 22px;
      margin-bottom: 10px;
    }
    .app-section p {
      font-size: 16px;
      margin-bottom: 20px;
    }
    .store-buttons img {
      max-width: 180px;
      margin: 10px;
    }
    .footer-note {
      background-color: #eaeaea;
      text-align: center;
      padding: 15px;
      font-size: 14px;
      color: #444;
    }
  </style>
</head>
<body>

  <header>
    <img src="logo.svg" alt="شعار سلامة" class="logo" />
  </header>

  <div class="main-content">
    <img src="salama-inspection-compressed.jpg" class="car-image" alt="صورة الفحص الفني للمركبة" style="width:100%; border-radius:10px; margin-bottom: 20px;" />
    <div class="title">خدمة الفحص الفني الدوري</div>
    <div class="subtitle">يمكنك حجز موعد جديد أو تعديل أو إلغاء موعدك</div>

    <div class="d-grid gap-3">
      <a href="booking-form-modern.php" class="btn btn-salama btn-hijz">حجز موعد</a>
      <a href="data.html" class="btn btn-salama btn-ta3deel">تعديل موعد</a>
      <a href="dashboard.php" class="btn btn-salama btn-ighaa">إلغاء موعد</a>
    </div>
  </div>

  <div class="app-section">
    <h2>يمكنك تحميل التطبيق الآن</h2>
    <p>يمكنك حجز موعد الفحص عن طريق التطبيق سلامة المركبات</p>
    <div class="store-buttons">
      <a href="https://play.google.com/store/apps/details?id=com.isoft.saso" target="_blank">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Google_Play_Store_badge_EN.svg/512px-Google_Play_Store_badge_EN.svg.png" alt="Google Play" />
      </a>
      <a href="https://apps.apple.com/app/id1614137306" target="_blank">
        <img src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg" alt="App Store" />
      </a>
    </div>
  </div>

  <div class="footer-note">إدارة حجز المواعيد</div>

</body>
</html>
