<footer style="background-color: #f8f9fa; padding: 20px 0; text-align: center; color: #6c757d; margin-top: 50px; font-size: 14px;">
  <div class="container">
    جميع الحقوق محفوظة &copy; <?php echo date("Y"); ?> جوال بي
  </div>
</footer>
</body>
</html>
