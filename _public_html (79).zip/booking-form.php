<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>نموذج حجز الفحص الفني</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background: linear-gradient(to right, #e8f5e9, #f1f8e9);
      padding: 50px;
    }
    .booking-card {
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
      max-width: 750px;
      margin: auto;
    }
    h2 {
      text-align: center;
      color: #1a6d3c;
      margin-bottom: 30px;
      font-weight: bold;
    }
    label {
      font-weight: bold;
      color: #333;
    }
    .form-control {
      border-radius: 8px;
      padding: 10px;
    }
    .btn-submit {
      background-color: #1a6d3c;
      color: white;
      padding: 14px;
      font-size: 18px;
      border: none;
      border-radius: 12px;
      width: 100%;
      transition: 0.3s;
    }
    .btn-submit:hover {
      background-color: #155d2c;
    }
  </style>
</head>
<body>

<div class="booking-card">
  <form action="booking.php" method="POST">
    <h2>نموذج حجز الفحص الفني الدوري</h2>
    <div class="mb-3">
      <label>الاسم الكامل</label>
      <input type="text" name="fullname" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>رقم الهوية</label>
      <input type="text" name="idnumber" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>رقم الجوال</label>
      <input type="text" name="phone" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>رقم اللوحة</label>
      <input type="text" name="vehiclenumber" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>نوع التسجيل</label>
      <select name="registrationtype" class="form-control" required>
        <option value="خصوصي">خصوصي</option>
        <option value="نقل عام">نقل عام</option>
        <option value="أجرة">أجرة</option>
        <option value="حكومي">حكومي</option>
      </select>
    </div>
    <div class="mb-3">
      <label>نوع المركبة</label>
      <select name="vehicletype" class="form-control" required>
        <option value="بنزين">بنزين</option>
        <option value="ديزل">ديزل</option>
        <option value="هايبرد">هايبرد</option>
        <option value="كهربائية">كهربائية</option>
      </select>
    </div>
    <div class="mb-3">
      <label>نوع الفحص</label>
      <select name="inspectiontype" class="form-control" required>
        <option value="فحص دوري">فحص دوري</option>
        <option value="فحص تسجيل جديد">فحص تسجيل جديد</option>
        <option value="إعادة فحص">إعادة فحص</option>
      </select>
    </div>
    <div class="mb-3">
      <label>المنطقة</label>
      <select name="city" class="form-control" required>
        <option value="الرياض">الرياض</option>
        <option value="مكة المكرمة">مكة المكرمة</option>
        <option value="جدة">جدة</option>
        <option value="المدينة المنورة">المدينة المنورة</option>
        <option value="الدمام">الدمام</option>
        <option value="أبها">أبها</option>
        <option value="الطائف">الطائف</option>
        <option value="القصيم">القصيم</option>
        <option value="حائل">حائل</option>
        <option value="تبوك">تبوك</option>
        <option value="نجران">نجران</option>
        <option value="جازان">جازان</option>
      </select>
    </div>
    <div class="mb-3">
      <label>تاريخ الموعد</label>
      <input type="date" name="date" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>الوقت</label>
      <input type="time" name="time" class="form-control" required>
    </div>
    <button type="submit" class="btn-submit">تأكيد الحجز</button>
  </form>
</div>

</body>
</html>