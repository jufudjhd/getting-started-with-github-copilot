<?php
session_start();
$client = $_SESSION['client_data'] ?? null;

if (!$client) {
    echo "<div style='text-align:center; padding: 50px;'>لا توجد بيانات حجز متاحة.</div>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>ملخص الحجز</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f8; padding: 40px; }
    .card { border: none; border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 20px; }
    .card h5 { color: #1a6d3c; font-weight: bold; margin-bottom: 15px; }
    .card-body span { font-weight: bold; color: #333; display: inline-block; width: 140px; }
    .pay-btn {
      background-color: #1a6d3c;
      color: white;
      font-size: 18px;
      padding: 12px 20px;
      border-radius: 10px;
      border: none;
    }
  </style>
</head>
<body>
<header style="text-align: center; background: #fff; padding: 20px; border-bottom: 3px solid #1a6d3c; margin-bottom: 30px;">
  <h1 style="color:#1a6d3c;">مركز سلامة المركبات</h1>
  <span style="color:#777;">ملخص الحجز الخاص بك</span>
</header>
<div class="container" style="max-width: 1000px; margin: auto;">
  <div class="card w-100">
    <div class="card-body">
      <h5>بيانات العميل</h5>
      <p><span>الاسم الكامل:</span> <?= htmlspecialchars($client['fullname']) ?></p>
      <p><span>رقم الجوال:</span> <?= htmlspecialchars($client['phone']) ?></p>
      
    </div>
  </div>
  <div class="card w-100">
    <div class="card-body">
      <h5>بيانات المركبة</h5>
      <p><span>رقم اللوحة:</span> <?= htmlspecialchars($client['vehiclenumber']) ?></p>
      <p><span>نوع التسجيل:</span> <?= htmlspecialchars($client['registrationtype']) ?></p>
      <p><span>نوع المركبة:</span> <?= htmlspecialchars($client['vehicletype']) ?></p>
      <p><span>نوع الفحص:</span> <?= htmlspecialchars($client['inspectiontype']) ?></p>
      <p><span>المنطقة:</span> <?= htmlspecialchars($client['city']) ?></p>
    </div>
  </div>
  <div class="card w-100">
    <div class="card-body text-center">
      <h5>ملخص الرسوم</h5>
      <p><span>تاريخ الموعد:</span> <?= htmlspecialchars($client['date']) ?></p>
      <p><span>الوقت:</span> <?= htmlspecialchars($client['time']) ?></p>
      <p style="font-size: 20px; margin: 15px 0;">رسوم الفحص: <strong>10 ريال</strong></p>
      <a href="payment.php" class="btn pay-btn">الدفع الآن</a>
    </div>
  </div>
</div>
</body>
</html>