<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>رمز التحقق</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css"
    rel="stylesheet"
  />
  <link
    href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap"
    rel="stylesheet"
  />
  <style>
    body {
      font-family: "Tajawal", sans-serif;
      background-color: #f9f9f9;
      padding: 30px;
      margin: 0;
    }
    header {
      background-color: white;
      padding: 15px 0;
      border-bottom: 3px solid #008aad;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-bottom: 40px;
      width: 100%;
    }
    header h1 {
      font-size: 24px;
      margin: 0;
      color: #1a6d3c;
      font-weight: 700;
    }
    header span {
      font-size: 14px;
      color: #777;
      display: block;
      margin-top: 4px;
    }
    form {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    h2 {
      color: #1a6d3c;
      margin-bottom: 15px;
    }
    label.desc {
      display: block;
      margin-bottom: 20px;
      font-size: 16px;
      color: #333;
    }
    input[type="text"] {
      max-width: 200px;
      margin: auto;
      text-align: center;
      font-size: 20px;
      letter-spacing: 10px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      outline: none;
    }
    input[type="text"]:focus {
      border-color: #1a6d3c;
      box-shadow: 0 0 8px #1a6d3caa;
    }
    .btn-next {
      width: 100%;
      padding: 12px;
      background-color: #1a6d3c;
      color: white;
      font-size: 18px;
      border: none;
      border-radius: 10px;
      transition: background-color 0.3s;
      margin-top: 25px;
    }
    .btn-next:hover {
      background-color: #155d2c;
    }
    .resend-section {
      margin-top: 20px;
      font-size: 14px;
      color: #555;
    }
    .resend-btn {
      background-color: transparent;
      border: none;
      color: #1a6d3c;
      cursor: pointer;
      font-weight: 700;
      text-decoration: underline;
      display: none;
      margin-top: 8px;
    }
    .resend-btn:disabled {
      color: gray;
      cursor: not-allowed;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <header>
    <h1>مركز سلامة المركبات</h1>
    <span>Vehicles Safety Center</span>
  </header>

  <form method="POST" action="verify_otp.php" autocomplete="off">
    <h2>رمز التحقق بعد الدفع</h2>
    <label class="desc">رمز التحقق المرسل إلى جوالك</label>
    <input
      type="text"
      name="otp_code"
      pattern="\d{4,6}"
      inputmode="numeric"
      maxlength="6"
      required
      autocomplete="one-time-code"
      autofocus
      placeholder="••••••"
    />

    <button type="submit" class="btn-next">متابعة</button>

    <div class="resend-section">
      <span>أعد إرسال الرمز بعد <span id="timer">120</span> ثانية</span><br />
      <button type="button" class="resend-btn" id="resendBtn">إعادة إرسال الرمز</button>
    </div>
  </form>

  <script>
    const timerElement = document.getElementById("timer");
    const resendBtn = document.getElementById("resendBtn");
    let timeLeft = 120;

    const countdown = setInterval(() => {
      timeLeft--;
      timerElement.textContent = timeLeft;

      if (timeLeft <= 0) {
        clearInterval(countdown);
        timerElement.parentElement.style.display = "none";
        resendBtn.style.display = "inline-block";
      }
    }, 1000);

    resendBtn.addEventListener("click", () => {
      resendBtn.disabled = true;
      resendBtn.textContent = "جارٍ الإرسال...";

      // هنا يمكن تضع كود AJAX لإعادة إرسال الرمز بدون إعادة تحميل الصفحة
      // مثلاً:
      // fetch('resend_otp.php', { method: 'POST' }).then(...)

      setTimeout(() => {
        timeLeft = 120;
        timerElement.textContent = timeLeft;
        timerElement.parentElement.style.display = "inline";
        resendBtn.style.display = "none";
        resendBtn.disabled = false;
        resendBtn.textContent = "إعادة إرسال الرمز";
        // هنا يمكن عرض رسالة نجاح إعادة الإرسال
        alert("تم إرسال رمز التحقق مرة أخرى.");
      }, 2000); // محاكاة وقت إرسال
    });
  </script>
</body>
</html>
