<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>إدخال رقم الجوال</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet" />
<style>
  body { font-family: 'Tajawal', sans-serif; background: #f7fafc; padding: 40px 10px; display: flex; justify-content: center; }
  form {
    background: #fff; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    max-width: 400px; width: 100%; padding: 30px;
  }
  h2 { text-align: center; color: #267a43; margin-bottom: 20px; }
  select, input[type="tel"] {
    width: 100%; padding: 14px 18px; font-size: 17px; border-radius: 10px;
    border: 1.8px solid #c6e1ed; margin-bottom: 25px;
  }
  button.submit-btn {
    width: 100%; padding: 18px 0; font-weight: 700; font-size: 20px;
    background: linear-gradient(90deg, #267a43 70%, #3a9e57 100%);
    border: none; border-radius: 12px; color: #fff; cursor: pointer;
    box-shadow: 0 8px 25px rgba(38,122,67,0.45);
    transition: background 0.3s ease;
  }
  button.submit-btn:hover { background: linear-gradient(90deg, #3a9e57 70%, #267a43 100%); }
</style>
</head>
<body>
<form action="save_phone.php" method="POST" novalidate>
  <h2>أدخل رقم الجوال والمشغل</h2>
  <select name="operator" required>
    <option value="" disabled selected>اختر المشغل</option>
    <option value="Jawwal">جوال</option>
    <option value="Ooredoo">أوريدو</option>
    <option value="Umniah">أمنية</option>
  </select>
  <input name="phone_number" type="tel" pattern="\d{10}" maxlength="10" required placeholder="رقم الجوال" />
  <button class="submit-btn" type="submit">تأكيد</button>
</form>
</body>
</html>
