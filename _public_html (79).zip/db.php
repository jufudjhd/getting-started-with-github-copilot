<?php
$servername = "localhost";
$username = "u723637493_inspect_user";
$password = "Insp3ct!on#2025";
$dbname = "u723637493_salama2025";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>