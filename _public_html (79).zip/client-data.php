<?php
session_start();
require_once 'db.php';

// جلب آخر حجز تم إدخاله من قاعدة البيانات (أو يمكنك التعديل لجلب الحجز حسب المستخدم أو الجلسة)
$query = "SELECT * FROM appointments ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);
$appointment = $result->fetch_assoc();

if (!$appointment) {
    echo "<p style='text-align:center;margin-top:50px;'>لا يوجد بيانات للحجز.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>ملخص حجز الموعد | مركز سلامة المركبات</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet" />
<style>
  body {
    font-family: 'Tajawal', sans-serif;
    background-color: #eef1f4;
    padding: 30px 15px;
    display: flex;
    justify-content: center;
  }
  .card {
    width: 90%;
    max-width: 900px;
    background: #fff;
    border-radius: 15px;
    padding: 30px 40px;
    box-shadow: 0 8px 25px rgb(38 122 67 / 0.15);
  }
  .section {
    margin-bottom: 30px;
  }
  .section:last-child {
    margin-bottom: 0;
  }
  .field {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #d6e4d4;
  }
  .field:last-child {
    border-bottom: none;
  }
  .field label {
    font-weight: 700;
    color: #1a6d3c;
    width: 40%;
  }
  .field span {
    color: #405c40;
    width: 60%;
    text-align: left;
    direction: ltr;
  }
  h2 {
    color: #267a43;
    margin-bottom: 25px;
    font-weight: 700;
    text-align: center;
  }
  @media (max-width: 600px) {
    .field {
      flex-direction: column;
      align-items: flex-start;
    }
    .field label, .field span {
      width: 100%;
      text-align: right;
      direction: rtl;
    }
    .field span {
      margin-top: 5px;
      font-size: 0.95rem;
    }
  }
</style>
</head>
<body>
<!-- رأس الصفحة مع الشعار الكامل -->
<header style="text-align: center; padding: 30px 0; background-color: #fff;">
  <img src="لقطة شاشة 2025-05-16 023244.png" alt="مركز سلامة المركبات" style="max-width: 100%; height: auto;">
</header>

<!-- رأس يحتوي على الشعار -->
<header style="background-color: #f8f9fa; padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
  <div class="container text-center">
    <img src="logo.png" alt="شعار الموقع" style="max-height: 60px;">
  </div>
</header>


<div class="card">
  <h2>ملخص حجز الموعد</h2>

  <div class="section">
    <div class="field"><label>الاسم الكامل:</label><span><?=htmlspecialchars($appointment['full_name'])?></span></div>
    <div class="field"><label>رقم الهوية الوطنية:</label><span><?=htmlspecialchars($appointment['national_id'])?></span></div>
    <div class="field"><label>رقم الجوال:</label><span><?=htmlspecialchars($appointment['phone'])?></span></div>
  </div>

  <div class="section">
    <div class="field"><label>رقم المركبة:</label><span><?=htmlspecialchars($appointment['vehicle_number'])?></span></div>
    <div class="field"><label>نوع المركبة:</label><span><?=htmlspecialchars($appointment['vehicle_type'])?></span></div>
    <div class="field"><label>موديل المركبة:</label><span><?=htmlspecialchars($appointment['vehicle_model'])?></span></div>
    <div class="field"><label>نوع الوقود:</label><span><?=htmlspecialchars($appointment['fuel_type'])?></span></div>
  </div>

  <div class="section">
    <div class="field"><label>نوع الفحص:</label><span><?=htmlspecialchars($appointment['inspection_type'])?></span></div>
    <div class="field"><label>المنطقة:</label><span><?=htmlspecialchars($appointment['region'])?></span></div>
    <div class="field"><label>التاريخ:</label><span><?=htmlspecialchars($appointment['aptment_date'])?></span></div>
    <div class="field"><label>الوقت:</label><span><?=htmlspecialchars($appointment['aptment_time'])?></span></div>
    <div class="field"><label>رمز الحجز:</label><span><?=htmlspecialchars($appointment['booking_code'])?></span></div>
  </div>
</div>

</body>
</html>
