<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>طلب حجز فحص فني</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family: 'Tajawal', sans-serif; background: linear-gradient(to right, #e3f2fd, #f1f8e9); }
    header { background-color: white; padding: 15px 0; border-bottom: 3px solid #008aad; text-align: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 40px; }
    header img.logo { height: 60px; margin-bottom: 5px; }
    header span { font-size: 14px; color: #777; display: block; margin-top: 2px; }
    .container-form { max-width: 800px; margin: auto; padding: 30px; background-color: #fff;
      border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); }
    .form-title { font-size: 20px; font-weight: 700; color: #1a6d3c; margin-bottom: 25px; text-align: center; }
    label { font-weight: 600; margin-bottom: 6px; display: block; }
    .form-control { border-radius: 10px; padding: 10px; }
    .btn-submit { background-color: #1a6d3c; color: #fff; border: none; font-size: 18px; border-radius: 10px;
      padding: 12px; width: 100%; transition: background 0.3s ease; margin-top: 20px; }
    .btn-submit:hover { background-color: #155d2c; }
    footer { text-align: center; background-color: #f8f9fa; color: #6c757d; padding: 20px;
      font-size: 14px; margin-top: 60px; border-top: 1px solid #e0e0e0; }
  </style>
</head>
<body>
<header>
  <h1>مركز سلامة المركبات</h1>
  <span>Vehicles Safety Center</span>
</header>
<div class="container container-form">
  <form action="booking.php" method="POST">
    <h2 class="form-title">طلب حجز فحص فني</h2>
    <div class="row g-3">
      <div class="col-md-6"><label>الاسم الكامل</label><input type="text" name="fullname" class="form-control" required /></div>
      <div class="col-md-6"><label>رقم الهوية</label><input type="text" name="idnumber" class="form-control" required /></div>
      <div class="col-md-6"><label>رقم الجوال</label><input type="text" name="phone" class="form-control" required /></div>
      <div class="col-md-6"><label>رقم اللوحة</label><input type="text" name="vehiclenumber" class="form-control" required /></div>
      <div class="col-md-6">
        <label>نوع التسجيل</label><select name="registrationtype" class="form-control" required>
          <option value="خصوصي">خصوصي</option><option value="نقل عام">نقل عام</option><option value="أجرة">أجرة</option><option value="حكومي">حكومي</option>
        </select>
      </div>
      <div class="col-md-6">
        <label>نوع المركبة</label><select name="vehicletype" class="form-control" required>
          <option value="بنزين">بنزين</option><option value="ديزل">ديزل</option><option value="هايبرد">هايبرد</option><option value="كهربائية">كهربائية</option>
        </select>
      </div>
      <div class="col-md-6">
        <label>نوع الفحص</label><select name="inspectiontype" class="form-control" required>
          <option value="فحص دوري">فحص دوري</option><option value="فحص تسجيل جديد">فحص تسجيل جديد</option><option value="إعادة فحص">إعادة فحص</option>
        </select>
      </div>
      <div class="col-md-6">
        <label>المنطقة</label><select name="city" class="form-control" required>
          <option value="الرياض">الرياض</option><option value="مكة المكرمة">مكة المكرمة</option><option value="جدة">جدة</option><option value="المدينة المنورة">المدينة المنورة</option>
          <option value="الدمام">الدمام</option><option value="أبها">أبها</option><option value="الطائف">الطائف</option><option value="القصيم">القصيم</option>
          <option value="حائل">حائل</option><option value="تبوك">تبوك</option><option value="نجران">نجران</option><option value="جازان">جازان</option>
        </select>
      </div>
      <div class="col-md-6"><label>تاريخ الموعد</label><input type="date" name="date" class="form-control" required /></div>
      <div class="col-md-6"><label>الوقت</label><input type="time" name="time" class="form-control" required /></div>
    </div>
    <button type="submit" class="btn-submit">تأكيد الحجز</button>
  </form>
</div>
<footer>جميع الحقوق محفوظة &copy; 2025 مركز سلامة المركبات</footer>
</body>
</html>