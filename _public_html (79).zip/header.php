<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>موقع الفحص الفني</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background-color: #f8f9fa;
    }
    .site-header {
      background-color: #ffffff;
      padding: 15px 0;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      margin-bottom: 30px;
    }
    .site-header .logo {
      max-height: 60px;
    }
    .user-info {
      font-weight: bold;
      color: #1a6d3c;
    }
  </style>
</head>
<body>

<header class="site-header">
  <div class="container d-flex justify-content-between align-items-center">
    <img src="logo.png" alt="شعار الموقع" class="logo">

    <div class="user-info">
      <?php if (isset($_SESSION['username'])): ?>
        مرحبًا، <?= htmlspecialchars($_SESSION['username']) ?>
      <?php else: ?>
        <a href="login.php" class="btn btn-outline-primary btn-sm">تسجيل الدخول</a>
      <?php endif; ?>
    </div>
  </div>
</header>
