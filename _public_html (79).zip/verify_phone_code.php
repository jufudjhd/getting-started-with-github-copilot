<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>رمز تحقق الجوال</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet" />
<style>
  body { font-family: 'Tajawal', sans-serif; background: #f7fafc; padding: 40px 10px; display: flex; justify-content: center; }
  form {
    background: #fff; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    max-width: 400px; width: 100%; padding: 30px;
  }
  h2 { text-align: center; color: #267a43; margin-bottom: 20px; }
  input[type="text"] {
    width: 100%; padding: 14px 18px; font-size: 18px; border-radius: 10px;
    border: 1.8px solid #c6e1ed; margin-bottom: 25px;
  }
  button.submit-btn {
    width: 100%; padding: 18px 0; font-weight: 700; font-size: 20px;
    background: linear-gradient(90deg, #267a43 70%, #3a9e57 100%);
    border
