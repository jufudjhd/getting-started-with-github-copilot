<?php
session_start();
ini_set('display_errors', 1); error_reporting(E_ALL);
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname         = trim($_POST['fullname'] ?? '');
    $idnumber         = trim($_POST['idnumber'] ?? '');
    $phone            = trim($_POST['phone'] ?? '');
    $vehiclenumber    = trim($_POST['vehiclenumber'] ?? '');
    $registrationtype = trim($_POST['registrationtype'] ?? '');
    $vehicletype      = trim($_POST['vehicletype'] ?? '');
    $inspectiontype   = trim($_POST['inspectiontype'] ?? '');
    $city             = trim($_POST['city'] ?? '');
    $date             = trim($_POST['date'] ?? '');
    $time             = trim($_POST['time'] ?? '');

    $stmt = $conn->prepare("INSERT INTO appointments (
        fullname, idnumber, phone, vehiclenumber, registrationtype,
        vehicletype, inspectiontype, city, date, time
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        die('خطأ في التحضير: ' . $conn->error);
    }

    $stmt->bind_param(
        "ssssssssss",
        $fullname, $idnumber, $phone, $vehiclenumber, $registrationtype,
        $vehicletype, $inspectiontype, $city, $date, $time
    );

    if ($stmt->execute()) {
        $_SESSION['appointment_id'] = $conn->insert_id;
        $_SESSION['client_data'] = [
            'fullname' => $fullname,
            'idnumber' => $idnumber,
            'phone' => $phone,
            'vehiclenumber' => $vehiclenumber,
            'registrationtype' => $registrationtype,
            'vehicletype' => $vehicletype,
            'inspectiontype' => $inspectiontype,
            'city' => $city,
            'date' => $date,
            'time' => $time
        ];
        header("Location: booking-summary-cards.php");
        exit;
    } else {
        echo "فشل في تنفيذ الإدخال: " . $stmt->error;
    }
}
?>